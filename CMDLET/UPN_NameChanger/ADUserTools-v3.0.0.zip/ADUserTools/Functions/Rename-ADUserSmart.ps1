function Rename-ADUserSmart {
    <#
    .SYNOPSIS
        Renames an AD User, updates UPN/Mail, and demotes old Primary SMTP to an Alias.

    .DESCRIPTION
        Performs a complete identity update for an Active Directory user:
        - Updates Display Name, GivenName, Surname
        - Changes SamAccountName and UserPrincipalName
        - Sets new Primary SMTP address
        - Preserves existing email aliases
        - Handles accidental deletion protection automatically

    .PARAMETER Identity
        Current username (SamAccountName) or UPN. If omitted, prompts interactively.

    .PARAMETER NewPrefix
        New username prefix without domain. If omitted, prompts interactively.

    .PARAMETER FirstName
        New first name. If omitted, prompts or keeps current.

    .PARAMETER LastName
        New last name. If omitted, prompts or keeps current.

    .EXAMPLE
        Rename-ADUserSmart -Identity "j.doe" -NewPrefix "john.smith" -FirstName "John" -LastName "Smith"

    .EXAMPLE
        Rename-ADUserSmart
        Runs in fully interactive mode with prompts.

    .NOTES
        Author: Andrew Jones
        Version: 3.0
        Requires: ActiveDirectory module
    #>

    #Requires -Modules ActiveDirectory

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [string]$Identity,

        [Parameter(Mandatory = $false)]
        [string]$NewPrefix,

        [Parameter(Mandatory = $false)]
        [string]$FirstName,

        [Parameter(Mandatory = $false)]
        [string]$LastName
    )

    # --- SETUP LOGGING ---
    $LogDir = "$env:TEMP\ADRenameLogs"
    if (!(Test-Path $LogDir)) { New-Item -Path $LogDir -ItemType Directory -Force | Out-Null }
    $Script:LogFile = "$LogDir\Log_$(Get-Date -Format 'yyyyMMdd_HHmm').txt"

    Start-Transcript -Path $Script:LogFile -Append | Out-Null

    try {
        Write-Host "`n========================================================" -ForegroundColor Cyan
        Write-Host "             AD IDENTITY UPDATE WIZARD                  " -ForegroundColor Cyan
        Write-Host "========================================================" -ForegroundColor Cyan

        # --- SEARCH ---
        if ([string]::IsNullOrWhiteSpace($Identity)) {
            $Identity = Read-Host "ENTER USERNAME OR EMAIL TO START"
        }

        Try {
            $User = Get-ADUser -Filter "UserPrincipalName -eq '$Identity' -or SamAccountName -eq '$Identity'" `
                               -Properties proxyAddresses, DisplayName, EmailAddress, UserPrincipalName, ProtectedFromAccidentalDeletion, GivenName, Surname `
                               -ErrorAction Stop
        }
        Catch {
            Write-Warning "Error contacting Active Directory: $($_.Exception.Message)"
            return
        }

        if (-not $User) {
            Write-Host "Status: NOT FOUND" -ForegroundColor Red
            return
        }
        
        Write-Host "Status: FOUND" -ForegroundColor Green
        Write-Host "Current Name: $($User.DisplayName)"
        Write-Host "Current UPN:  $($User.UserPrincipalName)"

        # --- INPUTS ---
        $DomainSuffix = if ($User.UserPrincipalName -match "@") { ($User.UserPrincipalName -split "@")[1] } else { Read-Host "Enter Domain (e.g. corp.com)" }

        if ([string]::IsNullOrWhiteSpace($NewPrefix)) {
            Write-Host "`n[TIP: Right-click to paste in most PowerShell windows]" -ForegroundColor Gray
            $NewPrefix = Read-Host "New Username (prefix only)" 
        }
        
        if ($NewPrefix -match "@") {
            Write-Warning "Invalid Input: Prefix cannot contain '@'."
            return
        }

        $NewFirstName = if ([string]::IsNullOrWhiteSpace($FirstName)) { Read-Host "New First Name (Enter to keep current)" } else { $FirstName }
        $NewLastName  = if ([string]::IsNullOrWhiteSpace($LastName)) { Read-Host "New Last Name (Enter to keep current)"  } else { $LastName }
        
        # Apply Defaults
        $NewFirstName = if ([string]::IsNullOrWhiteSpace($NewFirstName)) { $User.GivenName } else { $NewFirstName }
        $NewLastName  = if ([string]::IsNullOrWhiteSpace($NewLastName)) { $User.Surname } else { $NewLastName }

        $NewUPN = "$NewPrefix@$DomainSuffix"
        $NewDisplayName = "$NewFirstName $NewLastName"
        $NewSamAccount = $NewPrefix 

        # Forest-wide uniqueness check
        $Conflict = Get-ADUser -Filter "SamAccountName -eq '$NewSamAccount' -or UserPrincipalName -eq '$NewUPN'" -ErrorAction SilentlyContinue
        if ($Conflict -and $Conflict.ObjectGUID -ne $User.ObjectGUID) {
            Write-Warning "CONFLICT: The proposed username or UPN already exists for user: $($Conflict.Name)"
            return
        }

        # --- PROXY CALCULATION ---
        $EmailSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        if ($User.proxyAddresses) {
            foreach ($addr in $User.proxyAddresses) {
                $EmailSet.Add(($addr -replace '^(SMTP|smtp):', '')) | Out-Null
            }
        }
        if ($User.EmailAddress) { $EmailSet.Add($User.EmailAddress) | Out-Null }
        
        $EmailSet.Remove($NewUPN) | Out-Null
        
        $FinalProxies = [System.Collections.Generic.List[string]]::new()
        $FinalProxies.Add("SMTP:$NewUPN") 
        foreach ($email in $EmailSet) { $FinalProxies.Add("smtp:$email") }

        # --- CONFIRMATION ---
        Write-Host "`n[ PROPOSED CHANGES ]" -ForegroundColor Magenta
        Write-Host "--------------------------------------------------------"
        Write-Host "Display Name:  $($User.DisplayName) -> $NewDisplayName"
        Write-Host "SamAccount:    $($User.SamAccountName) -> $NewSamAccount"
        Write-Host "UserPrincipal: $($User.UserPrincipalName) -> $NewUPN"
        Write-Host "Primary SMTP:  $NewUPN"
        Write-Host "Aliases:       $($EmailSet.Count) addresses preserved."
        Write-Host "--------------------------------------------------------"
        
        if ((Read-Host "Type 'Y' to apply") -ne 'Y') { return }

        # --- EXECUTION ---
        Try {
            $WasProtected = $User.ProtectedFromAccidentalDeletion
            if ($WasProtected) {
                Write-Host "Unlocking object..."
                Set-ADObject -Identity $User.DistinguishedName -ProtectedFromAccidentalDeletion $false -ErrorAction Stop
            }

            $UserChanges = @{
                GivenName = $NewFirstName; Surname = $NewLastName; DisplayName = $NewDisplayName;
                SamAccountName = $NewSamAccount; UserPrincipalName = $NewUPN; EmailAddress = $NewUPN
            }
            
            Write-Host "Updating attributes..." -NoNewline
            Set-ADUser -Identity $User @UserChanges -Replace @{proxyAddresses = $FinalProxies.ToArray()} -ErrorAction Stop
            Write-Host "[ OK ]" -ForegroundColor Green

            Write-Host "Renaming AD Object..." -NoNewline
            Rename-ADObject -Identity $User -NewName $NewDisplayName -ErrorAction Stop
            Write-Host "[ OK ]" -ForegroundColor Green

            if ($WasProtected) {
                Write-Host "Relocking object..."
                $NewObj = Get-ADUser -Identity $NewSamAccount
                Set-ADObject -Identity $NewObj.DistinguishedName -ProtectedFromAccidentalDeletion $true -ErrorAction Stop
            }
            Write-Host "`n Success." -ForegroundColor Cyan
        }
        Catch {
            Write-Error "Error: $($_.Exception.Message)"
        }
    }
    finally {
        Stop-Transcript | Out-Null
        Write-Host "`nOpening Log: $Script:LogFile" -ForegroundColor Yellow
        Start-Process notepad.exe -ArgumentList $Script:LogFile
    }
}