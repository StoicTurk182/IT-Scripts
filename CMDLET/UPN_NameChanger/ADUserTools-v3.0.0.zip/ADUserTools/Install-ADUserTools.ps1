<#
.SYNOPSIS
    Installs ADUserTools module.

.PARAMETER Scope
    CurrentUser or AllUsers (AllUsers requires admin).

.PARAMETER Force
    Overwrite existing installation.

.EXAMPLE
    .\Install-ADUserTools.ps1 -Scope AllUsers -Force
#>

[CmdletBinding()]
param (
    [ValidateSet('CurrentUser', 'AllUsers')]
    [string]$Scope = 'CurrentUser',

    [switch]$Force
)

$ModuleName = "ADUserTools"
$SourcePath = Join-Path $PSScriptRoot $ModuleName

if (-not (Test-Path $SourcePath)) {
    Write-Error "Module source not found: $SourcePath"
    exit 1
}

# Determine paths
if ($Scope -eq 'AllUsers') {
    $IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $IsAdmin) {
        Write-Error "AllUsers requires administrator privileges."
        exit 1
    }
    $Targets = @(
        "$env:ProgramFiles\WindowsPowerShell\Modules\$ModuleName"
        "$env:ProgramFiles\PowerShell\Modules\$ModuleName"
    )
}
else {
    $Targets = @(
        "$env:USERPROFILE\Documents\WindowsPowerShell\Modules\$ModuleName"
        "$env:USERPROFILE\Documents\PowerShell\Modules\$ModuleName"
    )
}

Write-Host "`nInstalling $ModuleName..." -ForegroundColor Cyan

foreach ($Target in $Targets) {
    $TargetBase = Split-Path $Target -Parent
    
    # Create base directory if needed
    if (-not (Test-Path $TargetBase)) {
        New-Item -Path $TargetBase -ItemType Directory -Force | Out-Null
    }

    # Remove existing
    if (Test-Path $Target) {
        if (-not $Force) {
            $Confirm = Read-Host "Overwrite existing at $Target? (Y/N)"
            if ($Confirm -ne 'Y') { continue }
        }
        Remove-Item -Path $Target -Recurse -Force
    }

    # Copy module
    Copy-Item -Path $SourcePath -Destination $Target -Recurse -Force
    Write-Host "Installed: $Target" -ForegroundColor Green
}

# Verify
$Installed = Get-Module -ListAvailable -Name $ModuleName
if ($Installed) {
    Write-Host "`nSuccess! Version $($Installed[0].Version) installed." -ForegroundColor Green
    Write-Host "`nUsage:"
    Write-Host "  Import-Module $ModuleName"
    Write-Host "  Rename-ADUserSmart"
}
else {
    Write-Warning "Module installed but not detected. Restart PowerShell."
}