#Requires -Version 5.1

$FunctionPath = Join-Path -Path $PSScriptRoot -ChildPath "Functions"

Get-ChildItem -Path $FunctionPath -Filter "*.ps1" -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        . $_.FullName
    }
    catch {
        Write-Warning "Failed to load $($_.Name): $_"
    }
}

Export-ModuleMember -Function 'Rename-ADUserSmart'