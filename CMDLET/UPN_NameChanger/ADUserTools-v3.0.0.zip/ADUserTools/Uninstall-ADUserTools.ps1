$UninstallContent = @'
[CmdletBinding()]
param (
    [ValidateSet('CurrentUser', 'AllUsers', 'Both')]
    [string]$Scope = 'Both'
)

$ModuleName = "ADUserTools"
$Paths = @()

if ($Scope -in 'CurrentUser', 'Both') {
    $Paths += "$env:USERPROFILE\Documents\WindowsPowerShell\Modules\$ModuleName"
    $Paths += "$env:USERPROFILE\Documents\PowerShell\Modules\$ModuleName"
}

if ($Scope -in 'AllUsers', 'Both') {
    $Paths += "$env:ProgramFiles\WindowsPowerShell\Modules\$ModuleName"
    $Paths += "$env:ProgramFiles\PowerShell\Modules\$ModuleName"
}

Write-Host "Uninstalling $ModuleName..." -ForegroundColor Cyan

foreach ($Path in $Paths) {
    if (Test-Path $Path) {
        Remove-Item -Path $Path -Recurse -Force
        Write-Host "Removed: $Path" -ForegroundColor Green
    }
}

Write-Host "Done." -ForegroundColor Cyan
'@

$UninstallContent | Out-File "$BuildPath\Uninstall-ADUserTools.ps1" -Encoding UTF8